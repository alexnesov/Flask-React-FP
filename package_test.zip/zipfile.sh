#!/bin/bash

zip -r package_test.zip * .ebextensions

