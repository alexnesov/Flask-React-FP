GTS to be run thanks to this fundamental architecture soon.


# Flask-React-GTS

This is a simple app based on react with flask backend

### To start

`docker-compose up --build -d` <br>
`docker-compose up`

### To test

Open browser and hit localhost
http://localhost/

<br>
Tested on Docker version 20.10.14

### To stop
`docker-compose down`

### To list running containers
`docker ps`




### Documentation

`https://docs.docker.com/compose/gettingstarted/`
